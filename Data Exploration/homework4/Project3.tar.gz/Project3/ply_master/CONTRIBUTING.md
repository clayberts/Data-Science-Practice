Contributing to PLY
===================

PLY is a mature project. However, if you feel that you have found a
bug in PLY or its documentation, please submit an issue in the form
of a bug report.

Important note: The Github repo for PLY always contains the most
up-to-date version of the software.  If you want to use the current
version, you should COPY the contents of the `ply/` directory into
your own project and use it.  PLY is not maintained in as a package
installer.





