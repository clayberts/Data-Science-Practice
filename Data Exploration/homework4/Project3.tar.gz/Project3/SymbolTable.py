from msilib import Table
from turtle import left
from parser1 import Parser
import logging
from enum import Enum
import sys
import AST

class SymbolTable:
    def __init__(self, scope, table):
        self.scope = [[],[],[]]
        self.table = table
    
    def idLookUp(self, key):
        if key in self.table:
            return True
        else:
            return None

    def insert(self, scope, key, level, typesem):
        self.scope[level].append(self.table)