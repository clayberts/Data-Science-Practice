# ------------------------------------------------------------
# calclex.py
#
# tokenizer for a simple expression evaluator for
# numbers and +,-,*,/
# ------------------------------------------------------------
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from ply_master.ply import lex as lex

CONST_STR_VALUE = '(value = {})'
# List of token names.   This is always required
reserved = {
    'void': 'Void',
    'null': 'Null',
    'for': 'For',
    'while': 'While',
    'if': 'If',
    'else': 'Else',
    'return': 'Return',
    'break': 'Break',
    'print': 'Print',
    'ReadInteger': 'ReadInteger',
    'ReadLine': 'ReadLine',
    'int': 'Int',
    'double': 'Double',
    'string': 'String'
}

tokens = [
    'Op',
    'BoolConstant',
    'Identifier',
    'IntConstant',
    'DoubleConstant',
    'Or',
    'And',
    'LessEqual',
    'GreaterEqual',
    'Equal',
    'StringConstant',
    'LongIdentifier',
    'InvalidString'] + list(set(list(reserved.values())))

# Regular expression rules for simple tokens
t_Op             = r'\>|\<|\=|\+|-|\/|\*|\!|;|,|\{|\}|\(|\)|\.|\%'

def t_comments(t):
    r'\/\/.*|\/\*[\S\s]*\*\/'
    t.lexer.lineno += t.value.count('\n')

def t_InvalidString(t):
    r'\"[^\"\n]*\n'
    t.lexer.lineno += t.value.count('\n')
    t.error_message = 'Unterminated string constant: {}'.format(t.value)
    return t

def t_StringConstant(t):
    r'\"[^\"\n]*\"'
    t.info = CONST_STR_VALUE.format(t.value)
    return t

def t_BoolConstant(t):
    r'\btrue\b|\bfalse\b'
    t.info = CONST_STR_VALUE.format(t.value)
    return t

def t_Identifier(t):
    r'[a-zA-Z]\w*'
    if len(t.value) > 31:
        t.error_message = 'Identifier too long: "{}"'.format(t.value)
        t.info = '(truncated to {})'.format(t.value[:31])
    t.type = reserved.get(t.value, 'Identifier')

    return t

def t_DoubleConstant(t):
    # r'\d+\.\d*(E[\+\-]\d+)?'
    r'\d+\.\d*(E[\+\-]?\d+)?'
    if float(t.value) % 1 == 0:
        t.info = CONST_STR_VALUE.format(str(int(float(t.value))))
    else:
        t.info = CONST_STR_VALUE.format(str(float(t.value)))
    return t

# A regular expression rule with some action code
def t_IntConstant(t):
    # r'0[xX][a-fA-F0-9]+|\d+(?!\.)'
    r'0[xX][a-fA-F0-9]+|\d+'
    try:
        t.info = CONST_STR_VALUE.format(int(t.value, 0))
    except ValueError:
        t.info = CONST_STR_VALUE.format(int(t.value))
    return t

def t_Or(t):
    r'\|\|'
    return t

def t_And(t):
    r'\&\&'
    return t

def t_LessEqual(t):
    r'\<\='
    return t

def t_GreaterEqual(t):
    r'\>\='
    return t

def t_Equal(t):
    r'\=\='
    return t

# Define a rule so we can track line numbers
def t_newline(t):
    r'\n+'
    t.lexer.lineno += len(t.value)

# A string containing ignored characters (spaces and tabs)
t_ignore  = ' \t'

# Error handling rule
def t_error(t):
    t.lexer.skip(1)
    t.type = 'Error'
    t.value = t.value[0]
    t.error_message = "Unrecognized char: '{}'".format(t.value)
    return t

def return_lex_token(token, data):
    error_message = ''
    l_lex_with_error_messages = ['Identifier']

    if hasattr(token, 'error_message'):
        error_message = '\n*** Error line {}.\n*** {}\n'.format(token.lineno, token.error_message.rstrip())
    if not(error_message) or token.type in l_lex_with_error_messages:
        if token.type in l_lex_with_error_messages and error_message:
            error_message += '\n'

        lexpos = find_column(data, token)
        if token.type == 'Op':
            token_type = '{}'.format(token.value)

        else:
            token_type = 'T_' + token.type
        token_value = '{0:12}'.format(str(token.value))
        
        if not(hasattr(token, 'info')):
            token.info = ''

        return(error_message+'{} line {} cols {}-{} is {} {}'.format(token_value,
                                                         token.lineno,
                                                         lexpos,
                                                         lexpos+len(str(token.value))-1,
                                                         token_type,
                                                         token.info))
    else:
        return(error_message)

def return_lex_token_raw(token, data):
    error_message = ''
    l_lex_with_error_messages = ['Identifier']

    if hasattr(token, 'error_message'):
        error_message = '\n*** Error line {}.\n*** {}\n'.format(token.lineno, token.error_message.rstrip())
    if not(error_message) or token.type in l_lex_with_error_messages:
        if token.type in l_lex_with_error_messages and error_message:
            error_message += '\n'

        lexpos = find_column(data, token)
        if token.type == 'Op':
            token_type = '{}'.format(token.value)

        else:
            token_type = 'T_' + token.type
        # token_value = '{0:12}'.format(str(token.value))
        
        if not(hasattr(token, 'info')):
            token.info = ''

        if error_message:
            print(error_message)
            sys.exit()
        else:
            return((token_type,
                    token.value,
                    token.info,
                    token.lineno,
                    lexpos,
                    lexpos+len(str(token.value))-1))

def find_column(input, token):
    line_start = input.rfind('\n', 0, token.lexpos) + 1
    return (token.lexpos - line_start) + 1
 
def generate_lex_out(input_file):
    lexer = lex.lex()
    out_str = ''
    with open(input_file) as f:
        data = ''.join(f.readlines())

    # Give the lexer some input
        lexer.input(data)

        # Tokenize
        while True:
            tok = lexer.token()
            if not tok: 
                break      # No more input
            out_str += return_lex_token(tok, data) + '\n'

    return out_str


def tokenize(input_file):
    lexer = lex.lex()
    l_tokens = list()
    raw_data = None

    with open(input_file) as f:
        raw_data = f.readlines()
        data = ''.join(raw_data)

    # Give the lexer some input
        lexer.input(data)

        # Tokenize
        while True:
            tok = lexer.token()
            if not tok:
                break      # No more input
            l_tokens.append(return_lex_token_raw(tok, data))
    
    return (l_tokens, raw_data)

def main():
    print(generate_lex_out(sys.argv[1])[:-1])

if __name__ == "__main__":
    print('TYPE, VALUE, INFO, LINENO, COL_START, COL_END')
    for t in tokenize(sys.argv[1]):
        print(t)