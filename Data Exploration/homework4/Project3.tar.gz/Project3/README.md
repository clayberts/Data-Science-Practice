The code does not require a build because its python.

Then you can run the code by:
```/workdir/exec.sh input_file```

This will not print the correct results currently in stdout.

I added typechecking methods to a majority of the nodes, but had trouble figuring out how to handle function parameters. Symbol does not work.
Additionally, I debugged and troubleshot using visual studio code. Upon transfering everything over to the fox server, I'm having significantly more trouble running the code.
