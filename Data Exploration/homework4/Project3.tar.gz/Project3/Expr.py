from turtle import left
from parser1 import Parser
import logging
from enum import Enum
import sys
import AST

TYPE = 0
VALUE = 1
INFO = 2
LINE_NO = 3
COL_START = 4
COL_END = 5

LIST_TYPE = ['int', 'double', 'bool', 'string', 'void']

logging.basicConfig(level=logging.DEBUG)
_logger = logging.getLogger()

# Expr ::= LValue = Expr j Constant | LValue | Call | ( Expr ) |
# Expr + Expr | Expr - Expr | Expr * Expr | Expr = Expr |
# Expr % Expr | - Expr | Expr < Expr | Expr <= Expr |
# Expr > Expr | Expr >= Expr | Expr == Expr | Expr ! = Expr |
# Expr && Expr | Expr || Expr | ! Expr | ReadInteger ( ) |
# ReadLine ( )
# class Expr(ASTNode):
#     def __init__(self, parser, typ=None, identifier=None):
#         super().__init__(parser, typ=typ, identifier=identifier)
#         _logger.info('Expr: {}'.format(parser.current()))
class TypeC(Enum):
        VOID = "VOID"
        INT = "INT"
        STRING = "STRING"
        BOOL = "BOOL"
        DOUBLE = "DOUBLE"
        ERROR = "ERROR"

class ExprNode:
    def __init__(self, parser, operator:str, left=None, right=None):
        self.parser = parser
        self.operator = operator
        self.left = left
        self.right = right
        self.value = parser.current()
        self.typesem = None

        _logger.debug(self.__class__.__name__ + ': ' + str(parser.current()))

    def visit(self, spacing=0, prefix=None):
        if prefix:
            print(str(self.value[LINE_NO]).rjust(AST.PADDING, ' ') + AST.SPACE * spacing + '{} {}: '.format(prefix, self.__class__.__name__))

        else:
            print(str(self.value[LINE_NO]).rjust(AST.PADDING, ' ') + AST.SPACE * spacing + '{}: '.format(self.__class__.__name__))
        
        # print(self, self.left, self.operator, self.right)
        if self.left:
            self.left.visit(spacing+1)

        if self.operator:
            print(str(self.value[LINE_NO]).rjust(AST.PADDING, ' ') + AST.SPACE * (spacing+1) + 'Operator: {}'.format(self.operator))

        if self.right:
            self.right.visit(spacing+1)

    def typeCheck(self):
        self.left.typeCheck()
        if (self.right != None):
            self.right.typeCheck()
        if (self.left.typesem == TypeC.ERROR or self.right.typesem == TypeC.ERROR):
            self.typesem = TypeC.ERROR
            return
        if (self.operator == None):
            if (self.left == AST.Variable):
                var = self.left
                self.typesem = SymbolTable.lookupType(var.identifier)
            elif (self.left is AST.Constant and self.left.value[TYPE] == "T_IntConstant"):
                self.typesem = TypeC.INT
            elif (self.left is AST.Constant and self.left.value[TYPE] == "T_DoubleConstant"):
                self.typesem = TypeC.DOUBLE
            elif (self.left is AST.Constant and self.left.value[TYPE] == "T_BoolConstant"):
                self.typesem = TypeC.BOOL
            elif (self.left is AST.Constant and self.left.value[TYPE] == "T_StringConstant"):
                self.typesem = TypeC.STRING
            elif (self.left is AST.Call):
                self.typesem = self.left.typesem
            elif (self.left is AST.ReadIntegerExpr):
                self.typesem = self.left.typesem
            elif (self.left is AST.ReadLine):
                self.typesem = self.left.typesem
        if (self.operator == "-" and self.right == None):
            self.typesem = self.left.typesem
        elif (self.operator == "+" or self.operator == "-" or self.operator == "*" or self.operator == "/" or self.operator == "%"):
            if (self.left.typesem == self.right.typesem == TypeC.INT):
                self.typesem = TypeC.INT
            elif (self.left.typesem == self.right.typesem == TypeC.DOUBLE):
                self.typesem = TypeC.DOUBLE
            else:
                self.typesem = TypeC.ERROR
                raise AST.reportTypeError
        elif (self.operator == "<" or self.operator == ">" or self.operator == "<=" or self.operator == ">="):
            if (self.left.typesem == self.right.typesem == TypeC.INT):
                self.typesem = TypeC.BOOL
            elif (self.left.typesem == self.right.typesem == TypeC.DOUBLE):
                self.typesem = TypeC.BOOL
            else:
                self.typesem = TypeC.ERROR
                raise AST.reportTypeError

    def __str__(self):
        return '({})'.format(self.__class__.__name__)
    
def assignment(parser):
    exp = logical(parser)
    while parser.lookahead()[VALUE] == '=':
        n = parser.next()
        right = logical(parser)
        exp = AssignExpr(parser, n[VALUE], exp, right)

    return exp
        
def logical(parser):
    exp = equality(parser)
    while parser.lookahead()[VALUE] in ['&&', '||']:
        n = parser.next()
        right = equality(parser)
        exp = LogicalExpr(parser, n[VALUE], exp, right)

    return exp

def equality(parser):
    exp = relational(parser)
    while parser.lookahead()[VALUE] in ['!=', '==']:
        n = parser.next()
        right = relational(parser)
        exp = EqualityExpr(parser, n[VALUE], exp, right)

    return exp

def relational(parser):
    exp = arithmetic(parser)
    while parser.lookahead()[VALUE] in ['>=', '<=', '<', '>']:
        n = parser.next()
        right = arithmetic(parser)
        exp = RelationalExpr(parser, n[VALUE], exp, right)

    return exp

def arithmetic(parser):
    exp = multiplication(parser)
    while parser.lookahead()[VALUE] in ['+', '-']:
        n = parser.next()
        right = multiplication(parser)
        exp = ArithmeticExpr(parser, n[VALUE], exp, right)

    return exp

def multiplication(parser):
    exp = unary(parser)

    while parser.lookahead()[VALUE] in ['*', '/', '%']:
        n = parser.next()
        right = unary(parser)
        exp = ArithmeticExpr(parser, n[VALUE], exp, right)

    return exp

def unary(parser):
    # set to bypass unary for now
    exp = None
    if parser.lookahead()[VALUE] in ['-', '!']:
        n = parser.next()
        right = assignment(parser)
        exp = LogicalExpr(parser, n[VALUE], None, right)
        return exp
    # LV
    else:
        n = parser.lookahead()
        if n[TYPE] == 'T_Identifier':
            if parser.lookahead(2)[VALUE] == '(':
                return AST.Call(parser)
            else:
                return AST.LValue(parser, n[TYPE], n[VALUE])

        elif n[TYPE] in ['T_StringConstant', 'T_DoubleConstant', 'T_IntConstant', 'T_BoolConstant', 'T_Null']:
            return AST.Constant(parser, typ = n[TYPE][2:])

        elif n[VALUE] == '(':
            # digest (
            parser.next()
            exp = assignment(parser)

            if parser.next()[VALUE] != ')':
                raise AST.ParsingException(parser, '(')
            return exp

        elif n[VALUE] == 'ReadInteger':
            return AST.ReadIntegerExpr(parser)

        elif n[VALUE] == 'ReadLine':
            return AST.ReadLine(parser)

    return exp

# ! -
class LogicalExpr(ExprNode):
    pass

# * / % + -
class ArithmeticExpr(ExprNode):
    pass

# < <= > >= && ||
class RelationalExpr(ExprNode):
    pass

# == !=
class EqualityExpr(ExprNode):
    pass

# =
class AssignExpr(ExprNode):
    pass

if __name__ == '__main__':
    pass