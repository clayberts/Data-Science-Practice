#!/bin/bash

if [ ! -f "$1" ]
then
	echo "Invalid input file"
	exit 1
fi

code_path=${BASH_SOURCE[0]//exec.sh/../parser.py}
python3 $code_path $1
