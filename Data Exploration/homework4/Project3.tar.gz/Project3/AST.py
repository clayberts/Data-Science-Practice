from parser1 import Parser
import logging
from enum import Enum
import sys
from Expr import *

TYPE = 0
VALUE = 1
INFO = 2
LINE_NO = 3
COL_START = 4
COL_END = 5

PADDING = 3
SPACE = ' ' * PADDING
LINE_NO_PADDING = ' ' * 2
LIST_TYPE = ['int', 'double', 'bool', 'string', 'void']
breakFlag = False
funcPar = list()

logging.basicConfig(level=logging.DEBUG)
_logger = logging.getLogger()

# TODO: instead of using if else checks, maybe use collection of regeular expressions to
# check if the structure is correct???
class ParsingException(Exception):
    def __init__(self, parser:Parser, expected):
        super().__init__(self.__class__.__name__ + 'Expected: {} Found: {}'\
            .format(expected, parser.current()))
        
        token = parser.current()

        print()
        print('*** Error line {}.'.format(token[LINE_NO]))

        print(parser.get_line_no(token[LINE_NO]).rstrip())
        print(' ' * (token[COL_START]-1) + '^' * (token[COL_END]-token[COL_START]+1))

        print('*** syntax error')
        print()

class reportTypeError(Exception): 
    def __init__(self, parser:Parser, expected):
        super().__init__(self.__class__.__name__ + 'Expected: {} Found: {}'\
            .format(expected, parser.current()))
        
        token = parser.current()

        print()
        print('*** Error line {}.'.format(token[LINE_NO]))

        print(parser.get_line_no(token[LINE_NO]).rstrip())
        print(' ' * (token[COL_START]-1) + '^' * (token[COL_END]-token[COL_START]+1))

        print('*** Incompatible operands: ')
        print()

class TypeC(Enum):
        VOID = "VOID"
        INT = "INT"
        STRING = "STRING"
        BOOL = "BOOL"
        DOUBLE = "DOUBLE"
        ERROR = "ERROR"

class ASTNode:
    def __init__(self, parser:Parser, typ=None, identifier=None):
        self.parser = parser
        self.type = typ
        self.id = identifier
        self.value = parser.current()
        self.children = list()
        self.typesem = None
        _logger.debug(self.__class__.__name__ + ':' + str(parser.current()))

    def hasChildren(self):
        if len(self.children) != 0:
            return True
        else:
            return False

    def visit(self, spacing=0, prefix=None):
        if prefix:
            print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{} {}: '.format(prefix, self.__class__.__name__))

        else:
            print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{}: '.format(self.__class__.__name__))
        
        for c in self.children:
            c.visit(spacing+1)

    def __str__(self):
        return '({}: {} {})'.format(self.__class__.__name__, self.type, self.id)

class Program(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)

        while self.parser.lookahead():
            self.children.append(Decl(self.parser))

    def visit(self, spacing=0, prefix=None):
        print()
        print(SPACE * spacing + '{}: '.format(self.__class__.__name__))
        for c in self.children:
            c.visit(spacing)

    def typeCheck(self):
        for c in self.children:
            c.typeCheck()

    def __str__(self):
        return 'Program:'

def Decl(parser):
    if parser.lookahead(1)[VALUE] in LIST_TYPE:
        nn = parser.lookahead(2)
        if nn and nn[TYPE] == 'T_Identifier':
            nnn = parser.lookahead(3)
            if nnn and nnn[TYPE] == '(':
                return FnDecl(parser)
            else:
                return VarDecl(parser)
        else:
            parser.next()
            parser.next()
            raise ParsingException(parser, 'T_Identifier')
    else:
        parser.next()
        raise ParsingException(parser, 'T_Idenfier')


class VarDecl(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        # don't need type check here because we do it at Decl()?
        self.children.append(Variable(self.parser))

        if self.parser.lookahead()[VALUE] == ';':
            self.parser.next()
        else:
            raise Exception('; expected. Found:{}'.format(self.parser.current()))
        
    def visit(self, spacing=0, prefix=None):
        for c in self.children:
            c.visit(spacing, prefix)

class Variable(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        
        self.value = self.parser.next()
        self.type = self.value[VALUE]
        
        if self.type not in LIST_TYPE:
            raise ParsingException(self.parser, LIST_TYPE)

        n = self.parser.next()
        if n[TYPE] != 'T_Identifier':
            raise ParsingException(self.parser, 'T_Identifier')
        else:
            self.id = n[VALUE]

    def typeCheck(self):
        if (self.type == "int"):
            self.typesem = TypeC.INT
        elif (self.type == "double"):
            self.typesem = TypeC.DOUBLE
        elif (self.type == "bool"):
            self.typesem = TypeC.BOOL
        elif (self.type == "string"):
            self.typesem = TypeC.STRING
        elif (self.type == "void"):
            self.typesem = TypeC.VOID
        
        if (SymboleTable.idLookup(self.id) != None):
            self.typesem = TypeC.ERROR
            raise reportTypeError
        
        SymbolTable.insert(self.id, self.typesem)


    def visit(self, spacing=0, prefix=None):
        if prefix:
            print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{} {}: '.format(prefix, 'VarDecl'))
        else:
            print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{}: '.format('VarDecl'))
        
        print(SPACE * (spacing+2) + '{}: {}'.format('Type', self.type))
        print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * (spacing+1) + '{}: {}'.format('Identifier', self.id))


class Type(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
    def typeCheck(self):
        if (self.identifier == "int"):
            self.typesem = TypeC.INT
        elif (self.identifier == "double"):
            self.typesem = TypeC.DOUBLE
        elif (self.identifier == "bool"):
            self.typesem = TypeC.BOOL
        elif (self.identifier == "string"):
            self.typesem = TypeC.STRING

# FunctionDecl ::= Type ident ( Formals ) StmtBlock |
# void ident ( Formals ) StmtBlock
class FnDecl(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)

        self.value = parser.next()
        n = self.value
        
        if n[VALUE] in LIST_TYPE or n[VALUE] == 'void':
            self.type == n[VALUE]
            nn = parser.next()

            if nn[TYPE] == 'T_Identifier':
                self.id = nn[VALUE]
                self.parser.next()

                self.formals = Formals(self.parser)

                if self.parser.next()[VALUE] != ')':
                    raise ParsingException(self.parser, ')')

                self.stmtblock = StmtBlock(self.parser)
            else:
                # TODO: maybe error here?
                raise ParsingException(self.parser, 'T_Identifier')
        else:
            raise Exception('Expected Type or void')
    
    def typeCheck(self):
        self.formals.typeCheck()
        self.stmtblock.typeCheck()
        if (self.type == "int"):
            self.typesem = TypeC.INT
        elif (self.type == "double"):
            self.typesem = TypeC.DOUBLE
        elif (self.type == "bool"):
            self.typesem = TypeC.BOOL
        elif (self.type == "string"):
            self.typesem = TypeC.STRING
        elif (self.type == "void"):
            self.typesem = TypeC.VOID
        
        if (SymboleTable.idLookup(self.id) != None):
            self.typesem = TypeC.ERROR
            raise reportTypeError

        SymbolTable.insert(self.id, self.typesem)
        if (self.formals.typesem != TypeC.VOID or self.stmtblock.typesem != TypeC.VOID):
            self.typesem = TypeC.ERROR
            raise reportTypeError
        
        for c in self.formals.children:
            pass
                
    def visit(self, spacing=0, prefix=None):
        print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{}: '.format(self.__class__.__name__))
        print(SPACE * (spacing+2) + '(return type) Type: {}'.format(self.value[VALUE]))
        print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * (spacing+1) + 'Identifier: {}'.format(self.id))
        
        # for c in self.children:
        self.formals.visit(spacing, '(formals)')
        self.stmtblock.visit(spacing+1, '(body)')

    def __str__(self):
        return '\
            FnDecl:\n\
                '

# Formals ::= Variable+, @
class Formals(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)

        while self.parser.lookahead()[VALUE] != ')':
            self.children.append(Variable(self.parser, typ, identifier))

            if self.parser.lookahead()[VALUE] == ',':
                self.parser.next()
            else:
                break
        
    def typeCheck(self):
        for c in self.children:
            c.typeCheck()

    def visit(self, spacing=0, prefix=None):
        for c in self.children:
            c.visit(spacing+1, '(formals)')

# StmtBlock ::= { VariableDecl* Stmt* }
class StmtBlock(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)

        if self.parser.next()[VALUE] == '{':
            # TODO: finish here

            # while self.parser.lookahead()[VALUE] != '}'
            while self.parser.lookahead()[VALUE] != '}':

                if self.parser.lookahead()[VALUE] in LIST_TYPE:
                    self.children.append(VarDecl(self.parser))
                # while self.parser.lookahead()[VALUE] != '}':
                else:
                    self.children.append(stmt(self.parser))

                # exit the loop if EOF
                if not(self.parser.lookahead()):
                    raise ParsingException(self.parser, '}')
                
            # closing bracket detected from the loop above
            self.parser.next()
        else:
            raise Exception('Expected brace but found:{}'.format(self.parser.current()))
    
    def visit(self, spacing=0, prefix=None):
        if prefix:
            print(SPACE * (spacing+1) + '{} {}: '.format(prefix, self.__class__.__name__))
        else:
            print(SPACE * (spacing+1) + '{}: '.format(self.__class__.__name__))

        [c.visit(spacing+1) for c in self.children]

    def typeCheck(self):
        self.typesem = TypeC.VOID

    def __str__(self):
        return '({}: {})'.format(self.__class__.__name__, self.children)

# Stmt ::= <Expr>; | IfStmt | WhileStmt | ForStmt | BreakStmt |
# ReturnStmt | PrintStmt | StmtBlock
# class Stmt(ASTNode):
#     def __init__(self, parser:Parser, typ=None, identifier=None):
#         super().__init__(parser, typ=typ, identifier=identifier)

#         n = self.parser.lookahead()
#         if n[VALUE] == 'return':
#             self.children.append(ReturnStmt(self.parser))
#         elif n[VALUE] == 'if':
#             self.children.append(IfStmt(self.parser))
#         elif n[VALUE] == 'while':
#             self.children.append(WhileStmt(self.parser))
#         elif n[VALUE] == 'for':
#             self.children.append(ForStmt(self.parser))
        
#         # Expecting an expression, followed by ;
#         else:
#             self.children.append(assignment(parser))
#             n = self.parser.next()
    
#         if self.parser.current()[VALUE] != ';':
#             raise ParsingException(self.parser, ';')

def stmt(parser):
    n = parser.lookahead()
    result = None
    
    if n[VALUE] == 'return':
        result = ReturnStmt(parser)
    
    elif n[VALUE] == 'if':
        result = IfStmt(parser)
    
    elif n[VALUE] == 'while':
        result = WhileStmt(parser)
    
    elif n[VALUE] == 'for':
        result = ForStmt(parser)
    
    elif n[VALUE] == 'Print':
        result = PrintStmt(parser)

    elif n[VALUE] == ';':
        result = Empty(parser)

    elif n[VALUE] == 'break':
        result = BreakStmt(parser)
 
    # Expecting an expression, followed by ;
    else:
        result = assignment(parser)

        if parser.next()[VALUE] != ';':
            raise ParsingException(parser, ';')
    
    return result

class Empty(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        if self.parser.next()[VALUE] != ';':
            raise ParsingException(self.parser, ';')

    def visit(self, spacing=0, prefix=None):
        if prefix:
            print(SPACE * (spacing+1) + '{} {}: '.format(prefix, self.__class__.__name__))

        else:
            print(SPACE * (spacing+1) + '{}: '.format(self.__class__.__name__))

    def typeCheck(self):
        self.typesem = None

    def __str__(self):
        return '({})'.format(self.__class__.__name__)

class IfStmt(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        self.test = None
        self.body = None
        self.els = None

        if self.parser.next()[VALUE] == 'if':
            if self.parser.next()[VALUE] == '(':
                # test expression
                self.test = assignment(self.parser)

                if self.parser.next()[VALUE] == ')':
                    self.body = stmt(self.parser)

                    # else statement
                    if self.parser.lookahead()[VALUE] == 'else':
                        self.parser.next()
                        self.els = stmt(self.parser)
                else:
                    raise ParsingException(self.parser, ')')
            else:
                raise ParsingException(self.parser, '(')
        else:
            raise ParsingException(self.parser, 'if')
    
    def visit(self, spacing=0, prefix=None):
        print(SPACE * (spacing+1) + '{}: '.format(self.__class__.__name__))

        if self.test:
            self.test.visit(spacing+1, '(test)')

        if self.body:
            self.body.visit(spacing+1, '(then)')

        if self.els:
            self.els.visit(spacing+1, '(else)')

    def typeCheck(self):
        self.test.typeCheck()
        self.body.typeCheck()
        if (self.els != None):
            self.els.typeCheck()
        if (self.test.typesem == TypeC.BOOL and self.body.typesem == TypeC.VOID):
            if (self.els == None or self.els.type == TypeC.BOOL):
                 self.typesem = TypeC.VOID
            else:
                self.typesem = TypeC.ERROR
                raise reportTypeError
        else:
            self.type = SEM_LIST[5]
            raise reportTypeError

    def __str__(self):
        if self.els:
            return '({}: test:{} body:{} else:{})'.format(self.__class__.__name__, self.test, self.body, self.els)
        else:
            return '({}: test:{} body:{})'.format(self.__class__.__name__, self.test, self.body)

class WhileStmt(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        if self.parser.next()[VALUE] == 'while':
            if self.parser.next()[VALUE] == '(':
                self.test = assignment(self.parser)
                if self.parser.next()[VALUE] == ')':
                    self.body = StmtBlock(self.parser)
                else:
                    raise ParsingException(self.parser, ')')
            else:
                raise ParsingException(self.parser, '(')
        else:
            raise ParsingException(self.parser, 'while')
    
    def visit(self, spacing=0, prefix=None):
        print(SPACE * (spacing+1) + '{}: '.format(self.__class__.__name__))
        if self.test:
            self.test.visit(spacing+1, '(test)')

        if self.body:
            self.body.visit(spacing+1, '(body)')

    def typeCheck(self):
        breakFlag = True
        self.test.typeCheck()
        self.body.typeCheck()
        if (self.test.typesem == TypeC.BOOL and self.body.typesem == TypeC.VOID):
            self.typesem = TypeC.VOID
        else:
            self.typesem = TypeC.ERROR
            breakFlag = False
            raise reportTypeError 
        breakFlag = False

    def __str__(self):
        return '({}: test:{} body:{})'.format(self.__class__.__name__, self.test, self.body)

class ForStmt(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        if self.parser.next()[VALUE] == 'for':
            if self.parser.next()[VALUE] == '(':
                l_expr = list()
                i = 0
                while True:
                    n = self.parser.lookahead()[VALUE]
                    if i == 0:
                        if n == ';':
                            self.init = Empty(self.parser)
                        else:
                            self.init = assignment(self.parser)

                            if self.parser.next()[VALUE] != ';':
                                raise ParsingException(self.parser, ';')

                    elif i == 1:
                        self.test = assignment(self.parser)
                        # digiest ;
                        self.parser.next()

                    else:
                        self.step = assignment(self.parser)
                        if self.parser.next()[VALUE] == ')':
                            break
                        else:
                            raise ParsingException(self.parser, ')')

                    i += 1
                
                self.body = StmtBlock(self.parser)

            else:
                raise ParsingException(self.parser, '(')
        else:
            raise ParsingException(self.parser, 'for')

    def visit(self, spacing=0, prefix=None):
        print(SPACE * (spacing+1) + '{}: '.format(self.__class__.__name__))

        if self.init:
            self.init.visit(spacing, '(init)')

        if self.test:
            self.test.visit(spacing, '(test)')

        if self.step:
            self.step.visit(spacing, '(step)')

        if self.body:
            self.body.visit(spacing, '(body)')

    def typeCheck(self):
        self.init.typeCheck()
        self.test.typeCheck()
        self.step.typeCheck()
        self.body.typeCheck()
        breakFlag = True
        if (self.init.typesem == TypeC.INT and self.test.typesem == TypeC.BOOL and self.step.typesem == TypeC.INT and self.body.typesem == TypeC.VOID):
            self.typesem = TypeC.VOID
        else:
            self.typesem = TypeC.ERROR
            breakFlag = False
            raise reportTypeError
        breakFlag = False

    def __str__(self):
        return '({}: {} {} {} {})'.format(self.__class__.__name__, self.init, self.test, self.step, self.body)
    
# ReturnStmt ::= return < Expr > ;
##CHECK TYPE TO HAVE LEGAL RETURN
class ReturnStmt(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)

        # T_Return token digested
        self.value = self.parser.next()
        # may or may not be Expr
        exp = assignment(self.parser)
        if exp:
            self.children.append(exp)
            if self.parser.next()[VALUE] != ';':
                raise ParsingException(self.parser, ';')

        elif self.parser.lookahead()[VALUE] == ';':
            self.children.append(Empty(self.parser))
        else:
            raise Exception('; Expected but found {}'.format(n))

class BreakStmt(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        if self.parser.next()[VALUE] != 'break':
            raise ParsingException(self.parser, 'break')
        else:
            if self.parser.next()[VALUE] != ';':
                raise ParsingException(self.parser, ';')
        
    def typeCheck(self):
        if (breakFlag is False):
            raise reportTypeError
        else:
            self.typesem = TypeC.VOID

class PrintStmt(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        self.children = list()

        if self.parser.next()[VALUE] != 'Print':
            raise ParsingException(self.parser, 'Print')

        else:
            if self.parser.next()[VALUE] != '(':
                raise ParsingException(self.parser, '(')

            else:
                while self.parser.lookahead()[VALUE] != ')':
                    self.children += [assignment(self.parser)]

                    if self.parser.lookahead()[VALUE] == ',':
                        self.parser.next()
                
                # digest )
                self.parser.next()
                if self.parser.next()[VALUE] != ';':
                    raise ParsingException(self.parser, ';')

    def visit(self, spacing=0, prefix=None):
        print(SPACE * (spacing+1) + '{}: '.format(self.__class__.__name__))
        for c in self.children:
            c.visit(spacing+1, '(args)')

    def typeCheck(self):
        for c in self.children:
            c.typeCheck()
            if (c.typesem != TypeC.INT or c.typesem != TypeC.BOOL or c.typesem != TypeC.STRING):
                self.typesem = TypeC.ERROR
                raise reportTypeError 
                
        self.typesem = TypeC.VOID

    def __str__(self):
        return '({}: {})'.format(self.__class__.__name__, self.children)

class LValue(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        self.value = self.parser.next()

    def typeCheck(self):
        var = self.identifier
        self.typesem = SymbolTable.lookupType(var.identifier)

    def visit(self, spacing=0, prefix=None):
        if prefix:
            print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{} {}: '.format(prefix, 'FieldAccess'))
            print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * (spacing+1) + '{}: {}'.format('Identifier', self.value[VALUE]))

        else:
            print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{}: '.format('FieldAccess'))
            print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * (spacing+1) + '{}: {}'.format('Identifier', self.value[VALUE]))

        # print(SPACE * spacing + 'FieldAccess:')
        # print(SPACE * (spacing+1) + 'Identifier: {}'.format(self.value[VALUE]))

class Call(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        self.actuals = None
        # ident
        self.Identifier = self.parser.next()
        self.value = self.Identifier
        if self.Identifier[TYPE] != 'T_Identifier':
            raise ParsingException(self.parser, 'T_Identifier')

        if self.parser.next()[VALUE] == '(':
            self.actuals = Actuals(self.parser)

        else:
            raise ParsingException(self.parser, '(')

        # digest )
        if self.parser.next()[VALUE] != ')':
            print(self.parser.current())
            raise ParsingException(self.parser, ')')

    def typeCheck(self):
        var = self.Identifier
        self.typesem = SymbolTable.lookupType(var.identifier)
        self.actuals.typeCheck()
        if (self.actuals.typesem != TypeC.VOID):
            self.typesem = TypeC.ERROR
            raise reportTypeError
        else:
            for c in self.actuals.children:
                self
                funcPar.append()


    def visit(self, spacing=0, prefix=None):
        if prefix:
            print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{} {}: '.format(prefix, self.__class__.__name__))
        else:
            print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{}: '.format(self.__class__.__name__))
        
        print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * (spacing+1) +'Identifier: {}'.format(self.Identifier[VALUE]))            
        self.actuals.visit(spacing)

    def __str__(self):
        return '({}: Identifier:{} actuals:{})'.format(self.__class__.__name__,
                                                       self.Identifier,
                                                       self.actuals)

class Actuals(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        self.actuals = list()
        
        while self.parser.lookahead()[VALUE] != ')':
            self.actuals += [assignment(self.parser)]

            if self.parser.lookahead()[VALUE] == ',':
                self.parser.next()

    def typeCheck(self):
        for c in self.actuals():
            c.typeCheck()
            if (c.typesem == TypeC.INT):
                pass
            elif (c.typesem == TypeC.DOUBLE):
                pass
            elif (c.typesem == TypeC.BOOL):
                pass
            elif (c.typesem == TypeC.STRING):
                pass
            elif (c.typesem == TypeC.VOID):
                pass
            else:
                self.typesem = TypeC.ERROR
                raise reportTypeError

    def visit(self, spacing=0, prefix=None):
        [a.visit(spacing+1, '(actuals)') for a in self.actuals]

    def __str__(self):
        return '({}: actuals:{})'.format(self.__class__.__name__,
                                         self.actuals)

class Constant(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        self.value = self.parser.next()

    def visit(self, spacing=0, prefix=None):
        if self.value[TYPE] == 'T_DoubleConstant' and float(self.value[VALUE]) % 1 == 0:
            if prefix:
                print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{} {}: {}'.format(prefix, self.value[TYPE][2:], int(float(self.value[VALUE]))))
            else:
                print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{}: {}'.format(self.value[TYPE][2:], int(float(self.value[VALUE]))))
        else:
            if prefix:
                print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{} {}: {}'.format(prefix, self.value[TYPE][2:], self.value[VALUE]))
            else:
                print(str(self.value[LINE_NO]).rjust(PADDING, ' ') + SPACE * spacing + '{}: {}'.format(self.value[TYPE][2:], self.value[VALUE]))

    def __str__(self):
        return '({}: {})'.format(self.__class__.__name__, self.value[TYPE][2:],)

class ReadIntegerExpr(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        
        if self.parser.next()[VALUE] != 'ReadInteger':
            raise ParsingException(parser, 'ReadInteger')

        if self.parser.next()[VALUE] != '(':
            raise ParsingException(parser, '(')

        if self.parser.next()[VALUE] != ')':
            raise ParsingException(parser,')')

class ReadLine(ASTNode):
    def __init__(self, parser:Parser, typ=None, identifier=None):
        super().__init__(parser, typ=typ, identifier=identifier)
        
        if self.parser.next()[VALUE] != 'ReadLine':
            raise ParsingException(parser, 'ReadLine')

        if self.parser.next()[VALUE] != '(':
            raise ParsingException(parser, '(')

        if self.parser.next()[VALUE] != ')':
            raise ParsingException(parser,')')

if __name__ == '__main__':
    pass