import AST
import lex
import logging
import os
import sys

SAMPLES_DIR = 'pp2_samples/'
logging.basicConfig(level=logging.ERROR)

class Parser:
    def __init__(self, tup: list):
        self._logger = logging.getLogger(__name__)
        self.l_tokens = [''] + tup[0]
        self.raw_data = tup[1]
        self.pos = 0

    def lookahead(self, pos_offset=1):
        try:
            token = self.l_tokens[self.pos+pos_offset]
            # self._logger.debug('{}: lookahead {} in pos {}'\
            #     .format(self.lookahead.__name__, str(token), str(self.pos)))
            return token

        # EOF
        except IndexError as exception:
            return None

    def next(self):
        try:
            self.pos += 1
            token = self.l_tokens[self.pos]
            # self._logger.debug('{}: next token {} in pos {}'\
            #     .format(self.next.__name__, str(token), str(self.pos)))
            return token

        except IndexError as exception:
            return None

    def current(self):
        try:
            token = self.l_tokens[self.pos]
            # self._logger.debug('{}: current token {} in pos {}'\
            #     .format(self.current.__name__, str(token), str(self.pos)))
            return token
        
        except IndexError as exception:
            return None

    def get_tokens(self):
        return self.l_tokens[self.pos:]

    def get_line_no(self, lineno):
        return self.raw_data[lineno-1]

if __name__ == '__main__':
    if len(sys.argv) > 1:
        test_loc = sys.argv[1]
    else:
        test_loc = 'samples/bad1.decaf'


    tup = lex.tokenize(test_loc)    
    parser = Parser(tup)

    try:
        prog = AST.Program(parser)

    except AST.ParsingException as e:
        sys.exit()

    # prog.visit(spacing=1)
    prog.typeCheck()
